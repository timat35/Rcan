library(testthat)
library(Rcan)


test_check("Rcan")
